<h2>Welcome</h2>
<p style="font-family: cursive; font-size: 21px">
    This is the Admin Panel of the demo blog using codeigniter, bootstrap 3, mysql and backbone.js.
</p>
<p style="font-family: cursive; font-size: 21px">
Created By: Abhishek Banerjee </p>