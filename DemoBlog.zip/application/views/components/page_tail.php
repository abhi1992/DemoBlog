<br><br>
<div class="my-footer footer">
    <div class="container">
        <div class="row">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-9"><br><br></div>
                <div class="col-lg-3" style="text-align: right"><br><br><a href="#">TOP</a></div>
            </div>
        </div>
            </div>
        <div class="row">
        <div class=" col-lg-12">
        </div>
        </div>
        <div class="row">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12"><br><p>&copy; Abhishek Banerjee 2014 All rights reserved</p><br></div>
            </div>
        </div>
        </div>
    </div>
    
</div>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('b/js/bootstrap.min.js'); ?>"></script>
  </body>
</html>