<div class="row">
<!-- Main content -->
 		<div class="col-lg-9">
 			<article>
 				<h2><?php echo e($page->title); ?></h2>
 				<?php echo $page->body; ?> 
 			</article>
 		</div>
 		
 		<!-- Sidebar -->
<!-- 		<div class="col-lg-3 sidebar">
 			<h3>Recent </h3>
<?php//$this->load->view('sidebar'); ?>
 		</div>-->

</div>