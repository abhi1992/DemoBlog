var app = app || {};


$(function() {
	var c = new app.CommentsView();
    var b = new app.BlogsView();
});