var app = app || {};

    //demo data
    app.comments = [
        { pub_date: "", comment: "Some comment" },
        { nick: "C", pub_date: "", comment: "Some comment" },
        { nick: "Abh", pub_date: "", comment: "Some comment" },
        { nick: "Awe", pub_date: "", comment: "Some comment" },
        { nick: "Dude", pub_date: "", comment: "Some comment" },
    ];
    
    app.blogs = [{ blog: "gjhbkjgvjvgjhgvfhjvghj", nick: "Chgjhgjhgjghgj", pub_date: "lhmjbmjbmjkj", title: "enbjhvjhvhgvhgvhgt" },];