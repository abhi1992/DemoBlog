<?php
$config['site_name'] = 'cms';

