<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-04-25 16:33:41 --> Severity: Warning  --> mysql_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\Users\Abhishek\Downloads\Compressed\xampp\htdocs\DemoBlog\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-04-25 16:33:41 --> Severity: Warning  --> mysql_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\Users\Abhishek\Downloads\Compressed\xampp\htdocs\DemoBlog\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-04-25 16:33:41 --> Unable to connect to the database
ERROR - 2014-04-25 17:05:06 --> 404 Page Not Found --> public_html
ERROR - 2014-04-25 17:05:12 --> Severity: Warning  --> mysql_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\Users\Abhishek\Downloads\Compressed\xampp\htdocs\DemoBlog\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-04-25 17:05:12 --> Severity: Warning  --> mysql_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\Users\Abhishek\Downloads\Compressed\xampp\htdocs\DemoBlog\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-04-25 17:05:12 --> Unable to connect to the database
