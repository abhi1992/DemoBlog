<?php   ?>
<!DOCTYPE html>
<html>
  <head>
      <title><?php echo $meta_title;?></title>
    <!-- Bootstrap -->
    <link href="<?php echo base_url('b/css/bootstrap.min.css'); ?>" rel="stylesheet">
    
  </head>
