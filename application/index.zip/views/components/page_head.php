<?php   ?>
<!DOCTYPE html>
<html>
  <head>
      <title><?php echo config_item('site_name');?></title>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url('b/js/jquery.js'); ?>"></script>
    <!-- Bootstrap -->
    
    <link href="<?php echo base_url('b/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('b/css/styles.css'); ?>" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Josefin+Slab' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url('b/assets/JosefinSlab-Regular.ttf'); ?>" rel="stylesheet" type="text/css">
  </head>
