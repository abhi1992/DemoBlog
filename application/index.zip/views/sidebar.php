<div class="col-sm-3">
    <div class="list-group">
        <h3 class="list-group-item">Recent Blog</h3>
    <!--<hr>-->
    <a href="<?php echo site_url('/blog')?>" class="list-group-item"><i class="glyphicon glyphicon-plus"></i>  Blog Archive</a>
<?php echo article_links($recent_blog); ?>
    </div>
    </div>
